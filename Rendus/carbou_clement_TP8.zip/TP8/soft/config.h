#ifndef _CONFIG_H
#define _CONFIG_H

#define NB_PROCS    4
#define NB_MAXTASKS 1
#define NO_HARD_CC  0

#endif
