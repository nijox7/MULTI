#ifndef _CONFIG_H
#define _CONFIG_H

#define NB_PROCS    2
#define NB_MAXTASKS 4
#define NO_HARD_CC  0

#endif

